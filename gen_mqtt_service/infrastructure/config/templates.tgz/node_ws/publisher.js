/* -*- Mode: js; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * publisher.js
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program_name. If not, see <http://www.gnu.org/licenses/>.
 */

'use strict'

const mqtt = require('mqtt')
const clientId = 'mqttws_pub_' + Math.random().toString(16).substr(2, 8)
const host = process.env.MQTT_WS_URL || 'ws://localhost:8080'

const options = {
    keepalive: 30,
    clientId: clientId,
    clean: true,
    reconnectPeriod: 1000,
    connectTimeout: 30 * 1000
}

console.log('Connecting MQTT publisher via WebSocket to ' + host)
const client = mqtt.connect(host, options)

client.on('error', function (err) {
    console.error('Connection error:', err)
    client.end()
})

client.on('connect', function () {
    console.log('Publisher connected: ' + clientId)
    const payload = JSON.stringify({ message: 'Hello from ${PRO} over WebSocket!', timestamp: Date.now() })
    client.publish('topic/websocket', payload, { qos: 0, retain: false }, function () {
        console.log('Published message to topic/websocket')
        client.end()
    })
})

client.on('close', function () {
    console.log('Publisher disconnected')
})
