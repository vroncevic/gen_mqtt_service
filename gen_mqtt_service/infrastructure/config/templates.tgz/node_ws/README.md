# ${PRO} - Node.js WebSocket MQTT Service

MQTT service over WebSockets with an embedded WebSocket broker (Aedes + ws).

## Prerequisites

- Node.js (v18+)

## Installation

```bash
npm install
```

## Running

1. **Start the WebSocket MQTT Broker Server**:
   ```bash
   npm run start:server
   ```
   The WebSocket broker listens on port `8080` (`ws://localhost:8080`).

2. **Start the Subscriber**:
   ```bash
   npm run start:sub
   ```

3. **Start the Publisher**:
   ```bash
   npm run start:pub
   ```
