# ${PRO} - Node.js MQTT Service

MQTT client application implemented in Node.js using `mqtt`.

## Prerequisites

- Node.js (v18+)
- Docker (optional, for local broker)

## Installation

```bash
npm install
```

## Running Local MQTT Broker

```bash
docker compose up -d
```

## Running

```bash
# In terminal 1 (Subscriber):
npm run start:sub
# or: node subscriber.js

# In terminal 2 (Publisher):
npm run start:pub
# or: node publisher.js
```
