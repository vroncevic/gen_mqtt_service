# ${PRO} - Mosquitto C MQTT Service

MQTT client application implemented with `libmosquitto` in C.

## Prerequisites

Install development libraries and CMake build system:

```bash
# Debian / Ubuntu
sudo apt-get update && sudo apt-get install -y libmosquitto-dev build-essential cmake pkg-config
```

## Running Local MQTT Broker

```bash
docker compose up -d
```

## Building

Using CMake:

```bash
cmake -B build
cmake --build build
```

Or using Make wrapper:

```bash
make
```

## Running

```bash
# In terminal 1 (Subscriber):
./build/${PRO}_subscriber

# In terminal 2 (Publisher):
./build/${PRO}_publisher
```
