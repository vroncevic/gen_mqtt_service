/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * subscriber.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program_name. If not, see <http://www.gnu.org/licenses/>.
 */

#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>

static const char * const MQTT_HOSTNAME = "localhost";
static const int MQTT_PORT = 1883;
static const char * const MQTT_USERNAME = "vroncevic";
static const char * const MQTT_PASSWORD = "test";
static const char * const MQTT_TOPIC = "test";
static const int MQTT_KEEPALIVE = 60;
static const int MQTT_QOS = 0;
static const int LOOP_TIMEOUT = -1;
static const int MAX_PACKETS = 1;
static const int EXIT_ERROR = -1;
static const int EXIT_OK = 0;

void my_message_callback(
    struct mosquitto *mosq, void *obj,
    const struct mosquitto_message *message
)
{
    (void)mosq;
    (void)obj;
    printf("Got message: %s\n", (char *)message->payload);
}

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;

    struct mosquitto *mosq = NULL;
    mosquitto_lib_init();
    mosq = mosquitto_new(NULL, true, NULL);

    if (!mosq)
    {
        fprintf(stderr, "Can't init Mosquitto library\n");
        exit(EXIT_ERROR);
    }

    mosquitto_username_pw_set(mosq, MQTT_USERNAME, MQTT_PASSWORD);
    int ret = mosquitto_connect(mosq, MQTT_HOSTNAME, MQTT_PORT, MQTT_KEEPALIVE);

    if (ret)
    {
        fprintf(stderr, "Can't connect to Mosquitto server\n");
        exit(EXIT_ERROR);
    }

    ret = mosquitto_subscribe(mosq, NULL, MQTT_TOPIC, MQTT_QOS);

    if (ret)
    {
        fprintf(stderr, "Can't subscribe to Mosquitto server\n");
        exit(EXIT_ERROR);
    }

    mosquitto_message_callback_set(mosq, my_message_callback);
    mosquitto_loop_forever(mosq, LOOP_TIMEOUT, MAX_PACKETS);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return EXIT_OK;
}
