/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * subscriber.c
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program_name. If not, see <http://www.gnu.org/licenses/>.
 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>

#define MQTT_HOSTNAME "localhost" 
#define MQTT_PORT 1883
#define MQTT_USERNAME "vroncevic"
#define MQTT_PASSWORD "test"
#define MQTT_TOPIC "test"

int main (int argc, char **argv)
{
    struct mosquitto *mosq = NULL;
    mosquitto_lib_init();
    mosq = mosquitto_new (NULL, true, NULL);

    if (!mosq)
    {
        fprintf (stderr, "Can't initialize Mosquitto library\n");
        exit (-1);
    }

    mosquitto_username_pw_set (mosq, MQTT_USERNAME, MQTT_PASSWORD);
    int ret = mosquitto_connect (mosq, MQTT_HOSTNAME, MQTT_PORT, 0);

    if (ret)
    {
        fprintf (stderr, "Can't connect to Mosquitto server\n");
        exit (-1);
    }

    int i;
    char text[20];

    for (i = 0; i < 10; i++)
    {
        sprintf (text, "Hello, World %d", i);
        ret = mosquitto_publish (mosq, NULL, MQTT_TOPIC, 
        strlen (text), text, 0, false);
    
        if (ret)
        {
          fprintf (stderr, "Can't publish to Mosquitto server\n");
          
          exit (-1);
        }
    }

    sleep (1);
    mosquitto_disconnect (mosq);
    mosquitto_destroy (mosq);
    mosquitto_lib_cleanup();

    return 0;
}

