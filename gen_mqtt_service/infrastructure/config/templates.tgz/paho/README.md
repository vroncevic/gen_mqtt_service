# ${PRO} - Paho Python MQTT Service

Modular MQTT client application implemented in Python using `paho-mqtt`.

## Prerequisites

- Python 3.10+
- Docker (optional, for local broker)

## Installation

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Running Local MQTT Broker

```bash
docker compose up -d
```

## Running

```bash
# In terminal 1 (Subscriber):
python3 -m subscriber.main
# or: bash run_subscriber.sh

# In terminal 2 (Publisher):
python3 -m publisher.main
# or: bash run_publisher.sh
```
