#!/usr/bin/env bash
set -e

python3 -m subscriber.main
