# -*- coding: UTF-8 -*-

'''
Module
    mqtt_bundle.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines MQTT configuration parameter bundle.
'''

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@dataclass(slots=True, frozen=True, kw_only=True)
class MqttBundle:
    '''
        Defines bundle holding MQTT configuration parameters.

        It defines:

            :attributes:
                | DEFAULT_BROKER - Default MQTT broker host address.
                | DEFAULT_PORT - Default MQTT broker port number.
                | DEFAULT_TOPIC - Default MQTT topic.
                | DEFAULT_CLIENT_ID - Default MQTT client identifier.
                | DEFAULT_KEEPALIVE - Default connection keepalive interval.
                | DEFAULT_QOS - Default quality of service level.
                | broker - MQTT broker host address.
                | port - MQTT broker port number.
                | topic - MQTT topic to publish/subscribe.
                | client_id - Unique MQTT client identifier.
                | username - MQTT broker username.
                | password - MQTT broker password.
                | keepalive - Connection keepalive interval in seconds.
                | qos - Quality of service level (0, 1, 2).
                | verbose - Verbose logging flag.
            :methods:
                | to_dict - Converts the bundle attributes to a dictionary.
    '''

    DEFAULT_BROKER: ClassVar[str] = 'broker.emqx.io'
    DEFAULT_PORT: ClassVar[int] = 1883
    DEFAULT_TOPIC: ClassVar[str] = 'python/mqtt'
    DEFAULT_CLIENT_ID: ClassVar[str] = 'mqtt_client'
    DEFAULT_KEEPALIVE: ClassVar[int] = 60
    DEFAULT_QOS: ClassVar[int] = 0

    broker: str = DEFAULT_BROKER
    port: int = DEFAULT_PORT
    topic: str = DEFAULT_TOPIC
    client_id: str = DEFAULT_CLIENT_ID
    username: str | None = 'vroncevic'
    password: str | None = 'mypassword'
    keepalive: int = DEFAULT_KEEPALIVE
    qos: int = DEFAULT_QOS
    verbose: bool = False

    def to_dict(self) -> dict[str, object]:
        '''
            Converts the bundle attributes to a dictionary.

            :return: Dictionary representation of the bundle.
            :exceptions: None.
        '''
        return {
            'broker': self.broker,
            'port': self.port,
            'topic': self.topic,
            'client_id': self.client_id,
            'username': self.username,
            'password': self.password,
            'keepalive': self.keepalive,
            'qos': self.qos,
            'verbose': self.verbose
        }
