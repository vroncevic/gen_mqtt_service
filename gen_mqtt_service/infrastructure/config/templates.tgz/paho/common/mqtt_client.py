# -*- coding: UTF-8 -*-

'''
Module
    mqtt_client.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines MQTT client connection adapter with attribute(s) and method(s).
'''

from __future__ import annotations

from collections.abc import Callable
from types import TracebackType
from typing import ClassVar, Self

from paho.mqtt.client import CallbackAPIVersion, Client, MQTTMessage

from common.mqtt_bundle import MqttBundle

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class MqttClient:
    '''
        Defines MQTT client connection adapter.

        It defines:

            :attributes:
                | DEFAULT_CLIENT_ID - Default client identifier.
                | _bundle - Parameter bundle holding client configuration.
                | _raw_client - Underlying Paho MQTT client instance.
            :methods:
                | __init__ - Initializes MqttClient instance.
                | connect - Connects MQTT client to broker.
                | disconnect - Disconnects client from broker.
                | publish - Publishes message payload to MQTT topic.
                | subscribe - Subscribes client to MQTT topic.
                | set_on_message - Registers incoming message callback.
                | start_loop - Starts background network loop.
                | stop_loop - Stops background network loop.
                | __enter__ - Enters runtime context for context manager.
                | __exit__ - Exits runtime context and disconnects.
                | __str__ - Returns string representation of client.
    '''

    DEFAULT_CLIENT_ID: ClassVar[str] = 'mqtt_client'

    _bundle: MqttBundle
    _raw_client: Client

    def __init__(self, bundle: MqttBundle | None = None) -> None:
        '''
            Initializes MqttClient instance.

            :param bundle: MQTT configuration bundle | None.
            :exceptions: None.
        '''
        self._bundle = bundle or MqttBundle(client_id=self.DEFAULT_CLIENT_ID)
        self._raw_client = Client(
            CallbackAPIVersion.VERSION2, client_id=self._bundle.client_id
        )

        if self._bundle.username and self._bundle.password:
            self._raw_client.username_pw_set(
                self._bundle.username, self._bundle.password
            )

    def connect(self) -> bool:
        '''
            Connects MQTT client to broker.

            :return: True if connected successfully, False otherwise.
            :exceptions: None.
        '''
        try:
            rc: int = self._raw_client.connect(
                self._bundle.broker, self._bundle.port, self._bundle.keepalive
            )
            success: bool = (rc == 0)

            if self._bundle.verbose:
                if success:
                    print(
                        f'Connected client {self._bundle.client_id} to broker '
                        f'{self._bundle.broker}:{self._bundle.port}\n'
                    )
                else:
                    print(f'Failed to connect to broker (rc={rc})\n')
            return success

        except Exception as exc:
            if self._bundle.verbose:
                print(f'Connection failed: {exc}\n')

            return False

    def disconnect(self) -> None:
        '''
            Disconnects client from MQTT broker.

            :exceptions: None.
        '''
        self.stop_loop()
        self._raw_client.disconnect()

        if self._bundle.verbose:
            print('Disconnected from MQTT broker.\n')

    def publish(self, message: str, topic: str | None = None) -> bool:
        '''
            Publishes message payload to MQTT topic.

            :param message: Text payload to publish.
            :param topic: Target topic name or None for default topic.
            :return: True if publication succeeded, False otherwise.
            :exceptions: None.
        '''
        target_topic: str = topic or self._bundle.topic

        try:
            result = self._raw_client.publish(
                target_topic, message, qos=self._bundle.qos
            )
            success: bool = (result.rc == 0)

            if self._bundle.verbose:
                if success:
                    print(f'Send "{message}" to topic "{target_topic}"\n')
                else:
                    print(f'Failed to send message to topic "{target_topic}"\n')
            return success

        except Exception as exc:
            if self._bundle.verbose:
                print(f'Publish failed: {exc}\n')

            return False

    def subscribe(self, topic: str | None = None) -> bool:
        '''
            Subscribes client to MQTT topic.

            :param topic: Target topic name or None for default topic.
            :return: True if subscription succeeded, False otherwise.
            :exceptions: None.
        '''
        sub_topic: str = topic or self._bundle.topic

        try:
            result, _ = self._raw_client.subscribe(
                sub_topic, self._bundle.qos
            )
            success: bool = (result == 0)

            if self._bundle.verbose:
                if success:
                    print(f'Subscribed to topic "{sub_topic}"\n')
                else:
                    print(f'Failed to subscribe to topic "{sub_topic}"\n')
            return success

        except Exception as exc:
            if self._bundle.verbose:
                print(f'Subscribe failed: {exc}\n')

            return False

    def set_on_message(self, callback: Callable[[str, str], None]) -> None:
        '''
            Registers callback function for incoming MQTT messages.

            :param callback: Callable taking topic and payload strings.
            :exceptions: None.
        '''
        def on_message(
            _client: object, _userdata: object, msg: MQTTMessage
        ) -> None:
            payload: str = msg.payload.decode(errors='replace')
            callback(msg.topic, payload)

        self._raw_client.on_message = on_message

    def start_loop(self) -> None:
        '''
            Starts background network loop.

            :exceptions: None.
        '''
        self._raw_client.loop_start()

    def stop_loop(self) -> None:
        '''
            Stops background network loop.

            :exceptions: None.
        '''
        self._raw_client.loop_stop()

    def __enter__(self) -> Self:
        '''
            Enters runtime context for client.

            :return: MqttClient instance.
            :exceptions: None.
        '''
        self.connect()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None
    ) -> None:
        '''
            Exits runtime context and disconnects from broker.

            :param exc_type: Exception type.
            :param exc_val: Exception value.
            :param exc_tb: Traceback object.
            :exceptions: None.
        '''
        self.disconnect()

    def __str__(self) -> str:
        '''
            Returns string representation of client.

            :return: String representation.
            :exceptions: None.
        '''
        return (
            f'{self.__class__.__name__}(bundle={self._bundle!r}, '
            f'connected={self._raw_client.is_connected()!r})'
        )
