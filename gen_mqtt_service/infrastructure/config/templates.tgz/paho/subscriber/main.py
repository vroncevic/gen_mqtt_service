# -*- coding: UTF-8 -*-

'''
Module
    main.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Main entry point for MQTT subscriber demo.
'''

from __future__ import annotations

from sys import exit as sys_exit
from time import sleep

from subscriber.mqtt_subscriber import MqttSubscriber
from subscriber.mqtt_subscriber_factory import MqttSubscriberFactory

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


def main() -> bool:
    '''
        Bootstraps and runs the MQTT subscriber demo.

        :return: True if successful, False otherwise.
        :exceptions: None.
    '''
    try:
        subscriber: MqttSubscriber = MqttSubscriberFactory.create_from_params(
            verbose=True
        )

        if not subscriber.connect():
            return False

        if not subscriber.subscribe():
            return False

        subscriber.start_loop()

        try:
            while True:
                sleep(1.0)

        except KeyboardInterrupt:
            print('\nStopping subscriber...\n')
        finally:
            subscriber.stop_loop()
            subscriber.disconnect()

        return True

    except Exception as exc:
        print(f'Subscriber error: {exc}\n')

        return False


if __name__ == '__main__':
    '''
        Entry point for MQTT subscriber demo execution.

        :exit code: 0 if successful, 1 otherwise.
        :exceptions: None.
    '''
    sys_exit(0 if main() else 1)
