# -*- coding: UTF-8 -*-

'''
Module
    mqtt_subscriber_factory.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines factory class for creating MQTT subscriber instances.
'''

from __future__ import annotations

from common.mqtt_bundle import MqttBundle
from common.mqtt_client import MqttClient
from subscriber.imqtt_message_handler import IMqttMessageHandler
from subscriber.mqtt_message_handler import MqttMessageHandler
from subscriber.mqtt_subscriber import MqttSubscriber

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class MqttSubscriberFactory:
    '''
        Defines factory for creating MqttSubscriber instances.

        It defines:

            :methods:
                | create - Creates MqttSubscriber from bundle and handler.
                | create_from_params - Creates MqttSubscriber from parameters.
    '''

    @staticmethod
    def create(
        bundle: MqttBundle | None = None,
        handler: IMqttMessageHandler | None = None
    ) -> MqttSubscriber:
        '''
            Creates MqttSubscriber instance from bundle and handler.

            :param bundle: MQTT configuration bundle | None.
            :param handler: MQTT message handler interface | None.
            :return: Configured MqttSubscriber instance.
            :exceptions: None.
        '''
        client: MqttClient = MqttClient(bundle)
        msg_handler: IMqttMessageHandler = handler or MqttMessageHandler()

        return MqttSubscriber(client, msg_handler)

    @staticmethod
    def create_from_params(
        *,
        broker: str = MqttBundle.DEFAULT_BROKER,
        port: int = MqttBundle.DEFAULT_PORT,
        keepalive: int = MqttBundle.DEFAULT_KEEPALIVE,
        topic: str = MqttBundle.DEFAULT_TOPIC,
        qos: int = MqttBundle.DEFAULT_QOS,
        client_id: str = '89',
        username: str | None = None,
        password: str | None = None,
        verbose: bool = False,
        handler: IMqttMessageHandler | None = None
    ) -> MqttSubscriber:
        '''
            Creates MqttSubscriber instance from individual parameters.

            :param broker: Broker hostname or IP.
            :param port: Broker port.
            :param keepalive: Keepalive interval in seconds.
            :param topic: MQTT topic.
            :param qos: Quality of service level (0, 1, 2).
            :param client_id: Client identifier.
            :param username: Username for authentication | None.
            :param password: Password for authentication | None.
            :param verbose: Verbose logging flag.
            :param handler: MQTT message handler interface | None.
            :return: Configured MqttSubscriber instance.
            :exceptions: None.
        '''
        bundle: MqttBundle = MqttBundle(
            broker=broker,
            port=port,
            keepalive=keepalive,
            topic=topic,
            qos=qos,
            client_id=client_id,
            username=username,
            password=password,
            verbose=verbose
        )

        return MqttSubscriberFactory.create(bundle, handler)
