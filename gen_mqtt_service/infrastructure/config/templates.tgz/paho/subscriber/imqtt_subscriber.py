# -*- coding: UTF-8 -*-

'''
Module
    imqtt_subscriber.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines structural interface protocol for MQTT subscriber.
'''

from __future__ import annotations

from typing import Protocol, runtime_checkable

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@runtime_checkable
class IMqttSubscriber(Protocol):
    '''
        Defines protocol IMqttSubscriber with method(s).
        Provides an interface for MQTT subscriber operations.

        It defines:

            :methods:
                | connect - Connects MQTT client to broker.
                | disconnect - Disconnects client from broker.
                | subscribe - Subscribes client to configured topic.
                | start_loop - Starts background network loop.
                | stop_loop - Stops background network loop.
    '''

    def connect(self) -> bool:
        '''
            Connects MQTT client to broker.

            :return: True if connected successfully, False otherwise.
        '''

    def disconnect(self) -> None:
        '''
            Disconnects client from MQTT broker.
        '''

    def subscribe(self, topic: str | None = None) -> bool:
        '''
            Subscribes client to configured topic.

            :param topic: Topic name or None for default.
            :return: True if subscription request was sent, False otherwise.
        '''

    def start_loop(self) -> None:
        '''
            Starts background network loop.
        '''

    def stop_loop(self) -> None:
        '''
            Stops background network loop.
        '''
