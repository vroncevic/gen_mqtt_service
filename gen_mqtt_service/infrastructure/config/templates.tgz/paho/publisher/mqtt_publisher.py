# -*- coding: UTF-8 -*-

'''
Module
    mqtt_publisher.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines MQTT publisher class with attribute(s) and method(s).
'''

from __future__ import annotations

from types import TracebackType
from typing import Self

from common.imqtt_client import IMqttClient

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class MqttPublisher:
    '''
        Defines MQTT publisher client with attribute(s) and method(s).

        It defines:

            :attributes:
                | _client - MQTT client connection adapter interface.
            :methods:
                | __init__ - Initializes MqttPublisher with client adapter.
                | connect - Connects underlying client to broker.
                | disconnect - Disconnects underlying client from broker.
                | publish - Publishes message to MQTT topic.
                | start_loop - Starts background network loop.
                | stop_loop - Stops background network loop.
                | __enter__ - Enters runtime context for context manager.
                | __exit__ - Exits runtime context and disconnects.
                | __str__ - Returns string representation of publisher.
    '''

    _client: IMqttClient

    def __init__(self, client: IMqttClient) -> None:
        '''
            Initializes MqttPublisher with client adapter interface.

            :param client: MQTT client connection interface.
            :exceptions: None.
        '''
        self._client = client

    def connect(self) -> bool:
        '''
            Connects underlying client to broker.

            :return: True if connected successfully, False otherwise.
            :exceptions: None.
        '''
        return self._client.connect()

    def disconnect(self) -> None:
        '''
            Disconnects underlying client from broker.

            :exceptions: None.
        '''
        self._client.disconnect()

    def publish(self, message: str, topic: str | None = None) -> bool:
        '''
            Publishes message to configured MQTT topic.

            :param message: Text payload to publish.
            :param topic: Target topic name or None for default.
            :return: True if publication succeeded, False otherwise.
            :exceptions: None.
        '''
        return self._client.publish(message, topic)

    def start_loop(self) -> None:
        '''
            Starts background network loop.

            :exceptions: None.
        '''
        self._client.start_loop()

    def stop_loop(self) -> None:
        '''
            Stops background network loop.

            :exceptions: None.
        '''
        self._client.stop_loop()

    def __enter__(self) -> Self:
        '''
            Enters runtime context for publisher.

            :return: MqttPublisher instance.
            :exceptions: None.
        '''
        self.connect()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None
    ) -> None:
        '''
            Exits runtime context and disconnects from broker.

            :param exc_type: Exception type.
            :param exc_val: Exception value.
            :param exc_tb: Traceback object.
            :exceptions: None.
        '''
        self.disconnect()

    def __str__(self) -> str:
        '''
            Returns string representation of publisher.

            :return: String representation.
            :exceptions: None.
        '''
        return f'{self.__class__.__name__}(client={self._client!r})'
