# -*- coding: UTF-8 -*-

'''
Module
    mqtt_publisher_factory.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines factory class for creating MQTT publisher instances.
'''

from __future__ import annotations

from common.mqtt_bundle import MqttBundle
from common.mqtt_client import MqttClient
from publisher.mqtt_publisher import MqttPublisher

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class MqttPublisherFactory:
    '''
        Defines factory for creating MqttPublisher instances.

        It defines:

            :methods:
                | create - Creates MqttPublisher from bundle or default.
                | create_from_params - Creates MqttPublisher from parameters.
    '''

    @staticmethod
    def create(bundle: MqttBundle | None = None) -> MqttPublisher:
        '''
            Creates MqttPublisher instance from bundle.

            :param bundle: MQTT configuration bundle | None.
            :return: Configured MqttPublisher instance.
            :exceptions: None.
        '''
        client: MqttClient = MqttClient(bundle)

        return MqttPublisher(client)

    @staticmethod
    def create_from_params(
        *,
        broker: str = MqttBundle.DEFAULT_BROKER,
        port: int = MqttBundle.DEFAULT_PORT,
        keepalive: int = MqttBundle.DEFAULT_KEEPALIVE,
        topic: str = MqttBundle.DEFAULT_TOPIC,
        qos: int = MqttBundle.DEFAULT_QOS,
        client_id: str = '789',
        username: str | None = None,
        password: str | None = None,
        verbose: bool = False
    ) -> MqttPublisher:
        '''
            Creates MqttPublisher instance from individual parameters.

            :param broker: Broker hostname or IP.
            :param port: Broker port.
            :param keepalive: Keepalive interval in seconds.
            :param topic: MQTT topic.
            :param qos: Quality of service level (0, 1, 2).
            :param client_id: Client identifier.
            :param username: Username for authentication | None.
            :param password: Password for authentication | None.
            :param verbose: Verbose logging flag.
            :return: Configured MqttPublisher instance.
            :exceptions: None.
        '''
        bundle: MqttBundle = MqttBundle(
            broker=broker,
            port=port,
            keepalive=keepalive,
            topic=topic,
            qos=qos,
            client_id=client_id,
            username=username,
            password=password,
            verbose=verbose
        )

        return MqttPublisherFactory.create(bundle)
