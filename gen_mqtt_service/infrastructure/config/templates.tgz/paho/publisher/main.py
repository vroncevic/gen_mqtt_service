# -*- coding: UTF-8 -*-

'''
Module
    main.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Main entry point for MQTT publisher demo.
'''

from __future__ import annotations

from sys import exit as sys_exit
from time import sleep

from publisher.mqtt_publisher import MqttPublisher
from publisher.mqtt_publisher_factory import MqttPublisherFactory

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright ${YEAR}, https://vroncevic.github.io/${PRO}'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'https://github.com/vroncevic/${PRO}/blob/dev/LICENSE'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


def main() -> bool:
    '''
        Bootstraps and runs the MQTT publisher demo.

        :return: True if successful, False otherwise.
        :exceptions: None.
    '''
    try:
        publisher: MqttPublisher = MqttPublisherFactory.create_from_params(
            verbose=True
        )
        if not publisher.connect():
            return False

        publisher.start_loop()
        msg_count: int = 0

        try:
            while True:
                sleep(1.0)
                msg: str = f'messages: {msg_count}'
                publisher.publish(msg)
                msg_count += 1

        except KeyboardInterrupt:
            print('\nStopping publisher...\n')
        finally:
            publisher.stop_loop()
            publisher.disconnect()

        return True

    except Exception as exc:
        print(f'Publisher error: {exc}\n')

        return False


if __name__ == '__main__':
    '''
        Entry point for MQTT publisher demo execution.

        :exit code: 0 if successful, 1 otherwise.
        :exceptions: None.
    '''
    sys_exit(0 if main() else 1)
